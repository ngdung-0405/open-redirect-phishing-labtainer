#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

HOST = "0.0.0.0"
PORT = 80

LOGIN_PAGE = b"""
<html>
<head><title>Internal Training Portal</title></head>
<body>
<h2>Internal Training Portal</h2>
<p>This is the trusted school training portal.</p>
<form method="POST">
Username: <input name="username"><br>
Password: <input name="password" type="password"><br>
<input type="submit" value="Login">
</form>
</body>
</html>
"""

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)

        if parsed.path == "/":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Internal Training Portal is running. Open /login?next=/dashboard")
            return

        if parsed.path == "/login":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(LOGIN_PAGE)
            return

        if parsed.path == "/dashboard":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Welcome to internal dashboard.")
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)
        next_url = qs.get("next", ["/dashboard"])[0]

        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode(errors="ignore")
        fields = parse_qs(body)
        username = fields.get("username", [""])[0]
        password = fields.get("password", [""])[0]

        print("TRUSTED_LOGIN username=%s password=%s" % (username, password))
        print("OPEN_REDIRECT Location: %s" % next_url)

        self.send_response(302)
        self.send_header("Location", next_url)
        self.end_headers()

print("Target web listening on http://172.20.0.10")
HTTPServer((HOST, PORT), Handler).serve_forever()
