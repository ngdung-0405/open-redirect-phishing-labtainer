#!/bin/bash
echo "================================================="
echo " TARGET WEB IS RUNNING"
echo " URL: http://172.20.0.10/login?next=/dashboard"
echo " Vulnerable endpoint:"
echo " http://172.20.0.10/login?next=http://192.168.10.50/fake-login.html"
echo "================================================="
sudo python3 /home/ubuntu/target_server.py
