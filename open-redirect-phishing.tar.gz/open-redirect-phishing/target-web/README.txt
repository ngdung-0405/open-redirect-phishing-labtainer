Target web commands:
./run_target.sh
