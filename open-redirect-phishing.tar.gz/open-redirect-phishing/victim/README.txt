Victim workflow:

1. Open the training portal link provided in the email:
python3 victim_manual.py

Example training portal URL:
http://172.20.0.10/login?next=http://192.168.10.50/fake-login.html

2. If the portal asks for re-authentication:
python3 victim_reauth.py

Use the default URL by pressing Enter:
http://192.168.10.50/steal

3. Test alternate redirect URLs:
python3 test_bypass_payloads.py
