#!/usr/bin/env python3
import urllib.request
import urllib.parse

print("Open the training portal link provided in the email.")
trap_url = input("Training portal URL: ").strip()
username = input("Username: ").strip()
password = input("Password: ").strip()

data = urllib.parse.urlencode({
    "username": username,
    "password": password
}).encode()

req = urllib.request.Request(trap_url, data=data, method="POST")
opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler())

try:
    resp = opener.open(req, timeout=5)
    html = resp.read().decode(errors="ignore")

    print("final_url=%s" % resp.geturl())

    if "Your session has expired" in html or "re-authenticate" in html:
        print("reauthentication_required=yes")
        print("The portal asks you to re-authenticate.")
    else:
        print("reauthentication_required=no")

except Exception as e:
    print("victim_error=%s" % e)
