#!/bin/bash
echo "================================================="
echo " REAUTHENTICATION WEB SERVICE IS RUNNING"
echo " URL: http://192.168.10.50/fake-login.html"
echo " Captured credentials are logged locally for lab assessment."
echo "================================================="
sudo python3 /home/ubuntu/attacker_server.py
