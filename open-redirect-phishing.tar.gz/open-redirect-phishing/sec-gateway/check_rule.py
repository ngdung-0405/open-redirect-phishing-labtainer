#!/usr/bin/env python3
rules = open("open_redirect.rules").read()
ok = (
    "OPEN REDIRECT" in rules and
    "Location" in rules and
    "192.168.10." in rules and
    "sid:1001001" in rules
)
print("suricata_rule_created=yes" if ok else "suricata_rule_created=no")
