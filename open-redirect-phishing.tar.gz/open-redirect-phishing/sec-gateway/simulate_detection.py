#!/usr/bin/env python3
sample = "HTTP/1.0 302 Found\r\nLocation: http://192.168.10.50/fake-login.html\r\n\r\n"
rules = open("open_redirect.rules").read()
detected = "Location" in sample and "192.168.10." in sample and "OPEN REDIRECT" in rules
print("open_redirect_detected=yes" if detected else "open_redirect_detected=no")
