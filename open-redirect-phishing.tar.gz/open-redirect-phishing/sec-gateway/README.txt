Security gateway commands:
python3 check_rule.py
python3 simulate_detection.py
cat open_redirect.rules
cat defense_notes.txt
